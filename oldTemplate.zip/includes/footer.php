<div class="container py-md-4 mt-md-3">
	<div class="row footer-top-w3layouts-agile py-5">
		<div class="col-lg-3 col-md-6 col-sm-6 footer-grid">
			<div class="footer-title">
				<h3>About Us</h3>
			</div>
			<div class="footer-text">
				<p>
					UNICORN CAPITAL INVESTMENT LTD is committed to delivering robust services and results with a focus of becoming a well-known global investment services firm
					<a href="about.php">read more</a>
				</p>

			</div>
		</div>
		<div class="col-lg-3 col-md-6 col-sm-6 footer-grid">
			<div class="footer-title">
				<h3>Contact Us</h3>
			</div>
			<div class="footer-office-hour">
				<ul>
					<li class="hd">Corporate Head Office:</li>
					<li>Plot 1247, suit 9 5th floor, Aminu Kano Crescent Wuse 2 Abuja Fct</li>
					<li class="hd"><i class="fa fa-phone"></i>+234-90-76133334</li>
					<li class="hd">Processing Factory:</li>
					<li>Agbojedo Town
						Badagry Lagos state</li>
				</ul>
				<!-- <ul>
					<li class="hd">Phone:+ 1 (234) 567 8901</li>
					<li class="hd">Email:
						<a href="mailto:info@example.com">info@example.com</a>
					</li>
					<li class="hd">Fax: 1(234) 567 8901</li>
				</ul> -->
			</div>
		</div>
		<div class="col-lg-3 col-md-6 col-sm-6 footer-grid">
			<div class="footer-title">
				<h3>Contact Us</h3>
			</div>
			<div class="footer-office-hour">
				<ul>
				    <li class="hd"><a href="#">Abia Branch:</a></li>
					<li>104 Market Road Aba,
						Abia State.</li>
					<li class="hd">Port Harcourt Branch:</li>
					<li>Woji- Opening Soon.</li>
					<li class="hd">Nairobi Branch:</li>
					<li>Ambala road, off Kirinyaga cross road, Arcade House, Nairobi, Kenya
					</li>

				</ul>
				<!-- <ul>
					<li class="hd">Phone:+ 1 (234) 567 8901</li>
					<li class="hd">Email:
						<a href="mailto:info@example.com">info@example.com</a>
					</li>
					<li class="hd">Fax: 1(234) 567 8901</li>
				</ul> -->
			</div>
		</div>
		<div class="col-lg-3 col-md-6 col-sm-6 footer-grid">
			<div class="footer-title">
				<h3>Contact Us</h3>
			</div>
			<div class="footer-office-hour">
				<ul>
					<li class="hd">Nakuru Branch:</li>
					<li>Cigma Building,Mburu Gichua Rd,3rd floor, Office 229
						Nakuru, Kenya.</li>
					<li class="hd">Accra Branch:</li>
					<li>F22/8 Fifth Circular Rd. Labone,  Accra
						Ghana</li>
                    <li class="hd"><i class="fa fa-phone"></i>+233-236133397 </li>
				</ul>
				<!-- <ul>
					<li class="hd">Phone:+ 1 (234) 567 8901</li>
					<li class="hd">Email:
						<a href="mailto:info@example.com">info@example.com</a>
					</li>
					<li class="hd">Fax: 1(234) 567 8901</li>
				</ul> -->
			</div>
		</div>
	</div>
</div>